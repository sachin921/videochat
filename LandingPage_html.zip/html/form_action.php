<?php //echo "Rabindra";

     $result = $_POST;
	 //print_r($result);

     if($result){
    $message = '<html><body><span>Hi,</span><br><br>';    
    $message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
    foreach($result as $label => $postvalue){ 
        if (is_array($postvalue))
         {
            $chkvallue = implode(',' , $postvalue);        
            $message .= "<tr style='background: #eee;'><td><strong>".str_replace('_', ' ', ucfirst($label)).":</strong> </td><td>".$chkvallue."</td></tr>";           
        }
    	  else if(!empty($postvalue) && $postvalue != 'Submit')
         {
            $message .= "<tr style='background: #eee;'><td><strong>".str_replace('_', ' ', ucfirst($label)).":</strong> </td><td>".$postvalue."</td></tr>";
         }
    }
    $message .= "</table>";
    $message .= "</body></html><br>";
    $message .='Thanks & Regards';
    $to = "hello@skyposium.com";
    $subject = "Contact Us Email";
    echo $message;
    
    // To send HTML mail, the Content-type header must be set
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    // Additional headers
    $headers .= 'From: Code5 <hello@skyposium.com>' . "\r\n";

    // Mail it
    $mailsent = @mail($to, $subject, $message, $headers); 
    if($mailsent) echo 1; else echo 2;
    exit();   
    unset($_POST);
    unset($result);      
}

?>